"""User-facing game texts."""
