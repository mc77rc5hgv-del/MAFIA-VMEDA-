"""MAFIA VMEDA bot package."""
